#include"function.hpp"
int main()
{
    function();
}
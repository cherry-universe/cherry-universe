#include "function.hpp"

void function()
{
    std::cout<<"Hello,CMake World"<<std::endl;
}
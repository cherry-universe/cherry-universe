#ifndef FUNCTION
#define FUNCTION
#include<iostream>
void function();
#endif
#include"function.hpp"
int main()
{
#ifdef A
    function();
#else
    for(int i=0;i<100;++i)
        function();
#endif
}